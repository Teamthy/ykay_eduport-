/**
 * Ykay College — practice question bank.
 * Self-contained (offline). Merges curated questions with ported WAEC/SSCE
 * questions (Mathematics, Physics, English). MCQ + true/false only.
 */

export type Difficulty = "easy" | "medium" | "hard";

export interface PracticeQuestion {
  id: string;
  subject: string;
  difficulty: Difficulty;
  question: string;
  options: { key: string; text: string }[];
  correct: string;
  explanation: string;
}

export interface PracticeSubject {
  id: string;
  name: string;
  icon: string;
  color: string;
  questions: PracticeQuestion[];
}

export const PRACTICE_SUBJECTS: PracticeSubject[] = [
  {
    id: "mathematics",
    name: "Mathematics",
    icon: "📐",
    color: "#4EC54D",
    questions: [
      { id: "math-001", subject: "Mathematics", difficulty: "easy", question: "Solve for x:  2x + 5 = 15", options: [{ key: "a", text: "x = 3" }, { key: "b", text: "x = 5" }, { key: "c", text: "x = 7" }, { key: "d", text: "x = 10" }], correct: "b", explanation: "2x + 5 = 15 → 2x = 10 → x = 5." },
      { id: "math-002", subject: "Mathematics", difficulty: "medium", question: "If 3(x − 4) = 2(x + 1), find x.", options: [{ key: "a", text: "x = 10" }, { key: "b", text: "x = 14" }, { key: "c", text: "x = 8" }, { key: "d", text: "x = 12" }], correct: "b", explanation: "3x − 12 = 2x + 2 → x = 14." },
      { id: "math-003", subject: "Mathematics", difficulty: "medium", question: "What are the roots of  x² − 5x + 6 = 0?", options: [{ key: "a", text: "1 and 6" }, { key: "b", text: "2 and 3" }, { key: "c", text: "−2 and −3" }, { key: "d", text: "3 and −2" }], correct: "b", explanation: "x² − 5x + 6 = (x−2)(x−3) = 0 → x = 2 or 3. (WAEC 2020)" },
      { id: "math-004", subject: "Mathematics", difficulty: "easy", question: "If sin θ = 0.5, what is θ in degrees?", options: [{ key: "a", text: "30°" }, { key: "b", text: "45°" }, { key: "c", text: "60°" }, { key: "d", text: "90°" }], correct: "a", explanation: "sin 30° = 0.5. (WAEC 2019)" },
      { id: "math-005", subject: "Mathematics", difficulty: "easy", question: "Area of a circle of radius 7 cm (π = 22/7)?", options: [{ key: "a", text: "154 cm²" }, { key: "b", text: "44 cm²" }, { key: "c", text: "22 cm²" }, { key: "d", text: "77 cm²" }], correct: "a", explanation: "A = πr² = 22/7 × 49 = 154 cm². (WAEC 2021)" },
      { id: "math-006", subject: "Mathematics", difficulty: "easy", question: "17 is a prime number.", options: [{ key: "a", text: "True" }, { key: "b", text: "False" }], correct: "a", explanation: "17 is divisible only by 1 and itself." },
      { id: "math-008", subject: "Mathematics", difficulty: "medium", question: "Find the mean of: 4, 7, 8, 11, 15.", options: [{ key: "a", text: "8" }, { key: "b", text: "9" }, { key: "c", text: "10" }, { key: "d", text: "11" }], correct: "b", explanation: "Mean = 45/5 = 9." },
      { id: "math-009", subject: "Mathematics", difficulty: "hard", question: "Evaluate  log₁₀ 1000.", options: [{ key: "a", text: "2" }, { key: "b", text: "3" }, { key: "c", text: "4" }, { key: "d", text: "10" }], correct: "b", explanation: "log₁₀ 1000 = log₁₀ 10³ = 3. (WAEC 2022)" },
      { id: "m-c1", subject: "Mathematics", difficulty: "medium", question: "Factorise  x² − 5x + 6.", options: [{ key: "a", text: "(x−1)(x−6)" }, { key: "b", text: "(x−2)(x−3)" }, { key: "c", text: "(x+2)(x+3)" }, { key: "d", text: "(x−1)(x−5)" }], correct: "b", explanation: "x² − 5x + 6 = (x−2)(x−3)." },
    ],
  },
  {
    id: "english",
    name: "English Language",
    icon: "📖",
    color: "#FF9133",
    questions: [
      { id: "eng-001", subject: "English Language", difficulty: "easy", question: "“The teacher ___ the students to be quiet.”", options: [{ key: "a", text: "asked" }, { key: "b", text: "asking" }, { key: "c", text: "ask" }, { key: "d", text: "asks" }], correct: "a", explanation: "Past tense “asked” fits." },
      { id: "eng-002", subject: "English Language", difficulty: "medium", question: "Which is a complex sentence?", options: [{ key: "a", text: "I went to the market." }, { key: "b", text: "I went to the market and bought fruits." }, { key: "c", text: "When I went to the market, I bought fruits." }, { key: "d", text: "I went. I bought fruits." }], correct: "c", explanation: "A complex sentence has a dependent clause (“When…”) + independent clause." },
      { id: "e-c1", subject: "English Language", difficulty: "medium", question: "Antonym of “benevolent”?", options: [{ key: "a", text: "Kind" }, { key: "b", text: "Generous" }, { key: "c", text: "Malevolent" }, { key: "d", text: "Gentle" }], correct: "c", explanation: "“Malevolent” means wishing harm." },
      { id: "e-c2", subject: "English Language", difficulty: "medium", question: "“She is good ___ mathematics.” Preposition?", options: [{ key: "a", text: "in" }, { key: "b", text: "at" }, { key: "c", text: "on" }, { key: "d", text: "with" }], correct: "b", explanation: "“Good at” is the correct collocation for a skill." },
      { id: "e-c3", subject: "English Language", difficulty: "easy", question: "Which word is spelled correctly?", options: [{ key: "a", text: "Accomodation" }, { key: "b", text: "Acommodation" }, { key: "c", text: "Accommodation" }, { key: "d", text: "Acomodation" }], correct: "c", explanation: "Double c, double m." },
    ],
  },
  {
    id: "physics",
    name: "Physics",
    icon: "⚛️",
    color: "#3B82F6",
    questions: [
      { id: "phy-001", subject: "Physics", difficulty: "easy", question: "What is the SI unit of force?", options: [{ key: "a", text: "Joule" }, { key: "b", text: "Newton" }, { key: "c", text: "Watt" }, { key: "d", text: "Pascal" }], correct: "b", explanation: "Force is measured in Newtons (N)." },
      { id: "phy-002", subject: "Physics", difficulty: "medium", question: "A 5 kg body accelerates at 4 m/s². Force?", options: [{ key: "a", text: "10 N" }, { key: "b", text: "20 N" }, { key: "c", text: "25 N" }, { key: "d", text: "40 N" }], correct: "b", explanation: "F = ma = 5 × 4 = 20 N. (WAEC 2021)" },
      { id: "phy-003", subject: "Physics", difficulty: "easy", question: "Sound travels faster in air than in water.", options: [{ key: "a", text: "True" }, { key: "b", text: "False" }], correct: "b", explanation: "Sound travels faster in denser media (water > air)." },
      { id: "phy-005", subject: "Physics", difficulty: "medium", question: "Which lens corrects short-sightedness (myopia)?", options: [{ key: "a", text: "Convex" }, { key: "b", text: "Concave" }, { key: "c", text: "Bifocal" }, { key: "d", text: "Plano-convex" }], correct: "b", explanation: "Concave (diverging) lenses correct myopia. (WAEC 2020)" },
    ],
  },
  {
    id: "biology",
    name: "Biology",
    icon: "🧬",
    color: "#62D35E",
    questions: [
      { id: "b-c1", subject: "Biology", difficulty: "easy", question: "The “powerhouse” of the cell is the…", options: [{ key: "a", text: "Nucleus" }, { key: "b", text: "Ribosome" }, { key: "c", text: "Mitochondria" }, { key: "d", text: "Vacuole" }], correct: "c", explanation: "Mitochondria generate ATP — the cell’s energy." },
      { id: "b-c2", subject: "Biology", difficulty: "easy", question: "Plants make food through…", options: [{ key: "a", text: "Respiration" }, { key: "b", text: "Photosynthesis" }, { key: "c", text: "Transpiration" }, { key: "d", text: "Digestion" }], correct: "b", explanation: "Photosynthesis converts sunlight + CO₂ + water into glucose." },
      { id: "b-c3", subject: "Biology", difficulty: "medium", question: "Which blood cells fight infection?", options: [{ key: "a", text: "Red cells" }, { key: "b", text: "Platelets" }, { key: "c", text: "White cells" }, { key: "d", text: "Plasma" }], correct: "c", explanation: "White blood cells (leucocytes) fight pathogens." },
      { id: "b-c4", subject: "Biology", difficulty: "hard", question: "The basic unit of heredity is the…", options: [{ key: "a", text: "Chromosome" }, { key: "b", text: "Gene" }, { key: "c", text: "Allele" }, { key: "d", text: "Nucleotide" }], correct: "b", explanation: "A gene is the basic unit of heredity, made of DNA." },
    ],
  },
  {
    id: "civic",
    name: "Civic Education",
    icon: "🇳🇬",
    color: "#FF6E00",
    questions: [
      { id: "c-c1", subject: "Civic Education", difficulty: "easy", question: "How many states are in Nigeria?", options: [{ key: "a", text: "30" }, { key: "b", text: "36" }, { key: "c", text: "37" }, { key: "d", text: "40" }], correct: "b", explanation: "36 states + the FCT, Abuja." },
      { id: "c-c2", subject: "Civic Education", difficulty: "easy", question: "Nigeria’s National Assembly is…", options: [{ key: "a", text: "Unicameral" }, { key: "b", text: "Bicameral" }, { key: "c", text: "Tricameral" }, { key: "d", text: "Non-partisan" }], correct: "b", explanation: "Bicameral — Senate + House of Representatives." },
      { id: "c-c3", subject: "Civic Education", difficulty: "medium", question: "Which is a fundamental human right?", options: [{ key: "a", text: "Right to drive" }, { key: "b", text: "Right to life" }, { key: "c", text: "Right to a phone" }, { key: "d", text: "Right to vote early" }], correct: "b", explanation: "Right to life is fundamental." },
    ],
  },
];

export const ALL_PRACTICE_QUESTIONS = PRACTICE_SUBJECTS.flatMap((s) => s.questions);
